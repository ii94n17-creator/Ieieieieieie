const { Client } = require("discord.js");

const { Database } = require("st.db");

const coinsDB = new Database("/Json-Database/BotMaker/Balance.json");

const codesDB = new Database("/Json-Database/BotMaker/Codes.json");

const logsDB = new Database("/Json-Database/DashBoard/Logs.json");

const moment = require('moment-timezone');

module.exports = {

    name: `/redeem-code`,

    type: "post",

    run: async (req, res) => {

        const { code, userId } = req.body;

        

        // تحقق من صحة الكود

        let codeData = codesDB.get(`Code_${code}`);

        

        if (!codeData || codeData.used) {

            return res.send({

                data: {

                    alert: {

                        active: true,

                        type: 'error',

                        title: 'خطأ',

                        message: `الكود غير صالح أو تم استخدامه.`

                    }

                }

            });

        }

        

        // الحصول على عدد العملات من الكود

        const coinsAmount = codeData.amount;

        // إضافة العملات إلى رصيد المستخدم

        let userdata = await coinsDB.get(`User_${userId}`);

        if (!userdata) {

            userdata = { balance: 0 };

        }

        userdata.balance += coinsAmount;

        await coinsDB.set(`User_${userId}`, userdata);

        // تحديث حالة الكود إلى "مستخدم"

        await codesDB.set(`Code_${code}.used`, true);

        // إضافة سجل العملية

        const logId = logsDB.get(`LogID`) || 1;

        await logsDB.push(`Logs_${userId}`, {

            id: logId,

            reason: 'استخدام كود للحصول على عملات',

            amount: coinsAmount,

            status: 'success',

            action: 'استبدال كود',

            date: moment().format('YYYY-MM-DD hh:mm'),

        });

        logsDB.set(`LogID`, logId + 1);

        // رد بأن العملية تمت بنجاح

        return res.send({

            data: {

                alert: {

                    active: true,

                    type: 'success',

                    title: 'تمت العملية بنجاح',

                    message: `تم إضافة ${coinsAmount} عملات إلى حسابك.`

                }

            }

        });

    }

};