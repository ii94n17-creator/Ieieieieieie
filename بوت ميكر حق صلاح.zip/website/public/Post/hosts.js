const { Client, EmbedBuilder } = require("discord.js");
const moment = require('moment');
const { Database } = require("st.db");
const client = require("../../../").client;
const config = require('../../../config.json');
const logsdb = new Database("/Json-Database/DashBoard/Logs.json");
const IdsData = new Database("/Json-Database/BotMaker/IDs.json");

const products = [
    {
        title: 1,
        price: 100
    }
]
    
    


module.exports = {
    name: `/order/hosts`,
    type: "post",
    run: async (req, res) => {
        const balanceSchema = require('../../../Schema/Balance');
        let data = req.body;
let type = data.type
        let usercoins = 0;
        if (Object.keys(balanceSchema).length > 0) {
            let userdata = await balanceSchema.findOne({ userid: data.by, guild: config.MainGuild });
            usercoins = userdata?.balance || 0;
        }
        let productPrice = data.price;

        if (usercoins < productPrice) return res.send({
            data: {
                alert: {
                    active: true,
                    type: 'error',
                    title: 'خطأ',
                    message: `رصيدك غير كافٍ لإتمام هذه العملية.`
                }
            }
        });
const BotID = IdsData.get(`${type}ID`) || 1
        let purchasesID = IdsData.get(`PurchasesID`) || 1;
        IdsData.set(`PurchasesID`, purchasesID + 1);
IdsData.set(`${type}ID`, purchasesID + 1).then(() => {
    })

            
        let member = client.guilds.cache.get(config.MainGuild)?.members.cache.get(data.Buyer);

       const username = data.username

        let userdata = await balanceSchema.findOne({ userid: data.by, guild: config.MainGuild })
        // تحديث رصيد المستخدم
        userdata.balance = userdata.balance - +productPrice;
        userdata.coins = userdata.balance - +productPrice;
        userdata.save().then(async () => {

            // إرسال رسالة في روم معين عند الشراء
            let channel = client.channels.cache.get('1280158825290137761'); // استبدل CHANNEL_ID بمعرف الروم
            if (channel) {
                const purchaseEmbed = new EmbedBuilder()
                    .setFooter({ text: member.user.username, iconURL: member.user.displayAvatarURL({ dynamic: true }) })
                    .setTitle(`عملية شراء هوست جديدة`)
                    .setDescription(`**المشتري:** ${member.user.username}\n**المعرف الخاص بالعملية:** ${purchasesID}\n**السعر:** ${productPrice}\n**رقم الخطة: ${type}**`)
                    .setColor('Green')
                    .setTimestamp();

                channel.send({ embeds: [purchaseEmbed] });
            
           }
            const productLink = "http://nova-maker.000.pe/";
   member.send(`**# فاتورة شراء هوست

سعر : ${productPrice}

رقم الخطة : ${type}

مده  الاشتراك : month

تسجيل الدخول : [اضغط هنا](${productLink})**`).catch(console.error);
            // إضافة سجل الشراء في قاعدة البيانات
            logsdb.push(`Logs_${data.by}`, {
                id: purchasesID,
                reason: `شراء هوست`,
                amount: productPrice,
                status: 'success',
                action: 'شراء',
                date: moment().format('YYYY-MM-DD hh:mm'),
            });

            return res.send({
                data: {
                    alert: {
                        active: true,
                        type: 'success',
                        title: 'تمت العملية بنجاح',
                        message: `تم شراء هوست بنجاح.`
                    },
                    page: {
                        url: `/manage/hosts`
                    }
                }
            });

        }).catch(() => {
            return res.send({
                data: {
                    alert: {
                        active: true,
                        type: 'error',
                        title: 'خطأ',
                        message: `حدث خطأ أثناء تحديث البيانات.`
                    }
                }
            });
        });
    }
}
