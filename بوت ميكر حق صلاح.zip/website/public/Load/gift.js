const jwt = require(`jsonwebtoken`);

const jwt_secret = `Arabs-Dashhbooard-Seeeec-566604399523266580-Deves`;

const { Database } = require("st.db");

const moment = require('moment');

const coinsDB = new Database("/Json-Database/BotMaker/Balance.json");

const codesDB = new Database("/Json-Database/BotMaker/Codes.json");

const logsDB = new Database("/Json-Database/DashBoard/Logs.json");

module.exports = {

    // استدعاء الصفحة عبر GET

    name: `/redeem/load`,

    type: "get",

    run: async (req, res) => {

        let decoded;

        // التحقق من صلاحية التوكن

        try {

            decoded = jwt.verify(req.cookies.token, jwt_secret);

        } catch (e) {

            return res.redirect('/login'); // إعادة توجيه إذا لم يكن المستخدم مسجلاً

        }

        // إذا كان المستخدم مسجل الدخول

        if (decoded) {

            res.render(`./website/html/Pages/Dashboard/RedeemCode.ejs`, {

                user: {

                    avatar: decoded.user.avatar,

                    username: decoded.user.username,

                    discriminator: decoded.user.discriminator,

                    id: decoded.user.id,

                },

                data: {

                    page: 'redeem-code', // تخصيص الصفحة

                },

            });

        } else {

            return res.redirect('/login');

        }

    },

    // معالجة الكود عبر POST

    name: `/redeem/code`,

    type: "post",

    run: async (req, res) => {

        const { code } = req.body;

        let decoded;

        // التحقق من صلاحية التوكن

        try {

            decoded = jwt.verify(req.cookies.token, jwt_secret);

        } catch (e) {

            return res.send({

                data: {

                    alert: {

                        active: true,

                        type: 'error',

                        title: 'خطأ',

                        message: 'يجب عليك تسجيل الدخول.'

                    }

                }

            });

        }

        const userId = decoded.user.id;

        // التحقق من صحة الكود

        let codeData = codesDB.get(`Code_${code}`);

        if (!codeData || codeData.used) {

            return res.send({

                data: {

                    alert: {

                        active: true,

                        type: 'error',

                        title: 'خطأ',

                        message: `الكود غير صالح أو تم استخدامه.`

                    }

                }

            });

        }

        // إضافة العملات إلى رصيد المستخدم

        const coinsAmount = codeData.amount;

        let userdata = coinsDB.get(`User_${userId}`) || { balance: 0 };

        userdata.balance += coinsAmount;

        // تحديث رصيد المستخدم في قاعدة البيانات

        await coinsDB.set(`User_${userId}`, userdata);

        // تحديث حالة الكود ليصبح غير صالح للاستخدام

        await codesDB.set(`Code_${code}.used`, true);

        // إضافة السجل إلى سجل العمليات

        const logId = logsDB.get(`LogID`) || 1;

        await logsDB.push(`Logs_${userId}`, {

            id: logId,

            reason: 'استخدام كود للحصول على عملات',

            amount: coinsAmount,

            status: 'success',

            action: 'استبدال كود',

            date: moment().format('YYYY-MM-DD hh:mm'),

        });

        logsDB.set(`LogID`, logId + 1);

        // الرد على المستخدم بأن العملية تمت بنجاح

        return res.send({

            data: {

                alert: {

                    active: true,

                    type: 'success',

                    title: 'تمت العملية بنجاح',

                    message: `تم إضافة ${coinsAmount} عملات إلى حسابك.`

                }

            }

        });

    }

};