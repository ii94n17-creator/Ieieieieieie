const jwt = require(`jsonwebtoken`);
const jwt_secret = `Arabs-Dashhbooard-Seeeec-566604399523266580-Deves`;
const { Database } = require("st.db");
const paypal = require('@paypal/checkout-server-sdk');  // PayPal SDK
const moment = require('moment');
const config = require('../../../config.json');

// إعداد قواعد البيانات
const db = new Database("/Json-Database/DashBoard/UsersData.json");
const reviewsdb = new Database('/Json-Database/DashBoard/Reviews.json');
const weblanguagedb = new Database("/Json-Database/DashBoard/Language.json");
const logsdb = new Database("/Json-Database/DashBoard/Logs.json");

// إعداد PayPal Client
function environment() {
    return new paypal.core.SandboxEnvironment(
        "ARlkpeZjS7sAJMbzmpo1a8vXchjlIj140FTmxyb033p5UxgJVb6hYRl82WsmJ9uJ3jGnsysTwmYVwB6X",  // استبدل بـ Client ID من PayPal
        "EADZY6pQTqbSjiQ1A686rJ-XYus0SYMnAa0csfzEe4hJ5IKQO_FJ2LQ9je3nghcuCgjtM8F3vMqLsfpP"   // استبدل بـ Secret Key
    );
}

function client() {
    return new paypal.core.PayPalHttpClient(environment());
}

module.exports = {
    name: `/wallet/load`,
    type: "get",
    run: async (req, res) => {
        let decoded;
        try {
            decoded = jwt.verify(req.cookies.token, jwt_secret);
        } catch (e) {
            return res.redirect('/login');  // إعادة التوجيه إلى صفحة تسجيل الدخول إذا فشل التحقق
        }

        let reviews = reviewsdb.get('reviews') || [];
        let language = weblanguagedb.get(`${req.ip}`) || "EN";

        let args = {
            data: {
                reviews: reviews,
                language: language,
                login: false,
            },
        };

        if (decoded) {
            let data = db.get(decoded.uuid) || null;
            if (!data) {
                res.clearCookie(`token`);
                return res.redirect(`/`);
            }

            let userCoins = 0;
            let userData = await db.get(`User_${data.user.id}`) || { balance: 0 };
            userCoins = userData.balance;

            let logs = logsdb.get(`Logs_${data.user.id}`)?.reverse() || [];
            let userLanguage = weblanguagedb.get(`${data.user.id}`) || "EN";

            args = {
                ...args,
                user: {
                    avatar: data.user.avatar,
                    username: data.user.username,
                    discriminator: data.user.discriminator,
                    id: data.user.id,
                },
                data: {
                    ...args.data,
                    login: true,
                    userCoins: userCoins,
                },
                system: { logs: logs },
            };

            let blacklisted = await db.get(`Blacklist_${data.user.id}`);
            if (blacklisted) return res.redirect('/');

            return res.render(`./website/html/Pages/Dashboard/wallet.ejs`, args);
        } else {
            return res.redirect('/login');
        }
    },

    // مسار إنشاء طلب الدفع عبر PayPal
    createOrder: async (req, res) => {
        const { amount } = req.body;

        const request = new paypal.orders.OrdersCreateRequest();
        request.requestBody({
            intent: 'CAPTURE',
            purchase_units: [{ amount: { currency_code: 'USD', value: amount } }],
        });

        try {
            const order = await client().execute(request);
            res.json({ id: order.result.id });  // إرسال Order ID للعميل
        } catch (err) {
            console.error(err);
            res.status(500).send('Error creating PayPal order');
        }
    },

    // مسار التقاط الدفع وتحديث الرصيد
    captureOrder: async (req, res) => {
        const { orderID } = req.params;
        const { userId } = req.body;

        const request = new paypal.orders.OrdersCaptureRequest(orderID);
        request.requestBody({});

        try {
            const capture = await client().execute(request);
            const amount = parseFloat(capture.result.purchase_units[0].amount.value);

            // الحصول على بيانات المستخدم من st.db وتحديث الرصيد
            let userData = await db.get(`User_${userId}`) || { balance: 0 };
            userData.balance += amount;
            await db.set(`User_${userId}`, userData);

            // إضافة سجل العملية
            const logId = logsdb.get(`LogID`) || 1;
            await logsdb.push(`Logs_${userId}`, {
                id: logId,
                reason: 'شحن رصيد عبر PayPal',
                amount: amount,
                status: 'success',
                action: 'شحن رصيد',
                date: moment().format('YYYY-MM-DD hh:mm'),
            });
            logsdb.set(`LogID`, logId + 1);

            res.json({ message: 'Payment successful!', newBalance: userData.balance });
        } catch (err) {
            console.error(err);
            res.status(500).send('Error capturing PayPal order');
        }
    },
};
