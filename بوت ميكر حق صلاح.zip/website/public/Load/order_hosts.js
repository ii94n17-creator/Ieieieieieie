const jwt = require(`jsonwebtoken`);
const jwt_secret = `Arabs-Dashhbooard-Seeeec-566604399523266580-Deves`;
const { Database } = require("st.db");
const moment = require('moment');
const fs = require('fs');
const path = require('path');
let reviewsdb = new Database('/Json-Database/DashBoard/Reviews.json')
const db = new Database("/Json-Database/DashBoard/UsersData.json");
const IdsData = new Database("/Json-Database/BotMaker/IDs.json");
const Prices = new Database("/Json-Database/BotMaker/Prices.json");
const weblanguagedb = new Database("/Json-Database/DashBoard/Language.json");
const cardsDB = new Database("/Json-Database/DashBoard/Cards2.json");
const logsdb = new 
Database("/Json-Database/DashBoard/Logs.json");

//let stockPath = '/home/container/Json-Database/DashBoard/Cards2.json';
//let stockData = '/home/container/Json-Database/DashBoard/Cards2.json';



const stockPath = path.join(__dirname, '../../../Json-Database/DashBoard/Cards2.json');


const config = require('../../../config.json');

function getStock() {
    const stockData = fs.readFileSync(stockPath);
    return JSON.parse(stockData);
}

function updateStock(type, productId) {
    const stock = getStock();
    const product = stock[type].find(p => p.id === productId);
    if (product) {
        product.available = false;
        fs.writeFileSync(stockPath, JSON.stringify(stock, null, 4));
    }
}

module.exports = {
    name: `/order/hosts/load`,
    type: "get",
    run: async (req, res) => {
        const balanceSchema = require('../../../Schema/Balance');
        const blacklistSchema = require('../../../Schema/Blacklist');
        let decoded;

        try {
            decoded = jwt.verify(req.cookies.token, jwt_secret);
        } catch (e) { }

        let reviews = reviewsdb.get('reviews') || []
       let stock = getStock();  // قراءة المخزون

        let productType = req.query.type || 'defaultType'; // نوع المنتج المطلوب
        let productData1 = stock[productType]?.filter(p => p.available) || [];
        let productData = cardsDB.get(`products`)?.filter(c => !c.mainServer || !c.mainServer == 'true')|| []

        let products = []
        productData.forEach((product, i) => {
            if (i + 1 > 4) return
            let p = Prices.get(`${product.name}P_${config.MainGuild}`) || 10
            product.price = p
            products.push({ ...product })
        });

        let language;
        let languagedb = weblanguagedb.get(`${req.ip}`) || "EN"
        language = languagedb
        let args = {
            orderCards: {
                Products: products
            },
            data: {
                reviews: reviews,
                language: language,
                login: false,
            },
        }

        if (decoded) {
            let data = db.get(decoded.uuid) || null
            if (!data) {
                res.clearCookie(`token`);
                res.redirect(`/`);
                return
            }

            if (req.cookies.token) {

                let usercoins = 0
                if (Object.keys(balanceSchema).length > 0) {
                    let userdata = await balanceSchema.findOne({ userid: data.user.id, guild: config.MainGuild })
                    usercoins = userdata?.balance || 0
                }

                let productData1 = stock[productType]?.filter(p => p.available) || [];
                let products = []

                productData.forEach(product => {
                    let p = Prices.get(`${product.name}P_${config.MainGuild}`) || 10
                    product.price = p
                    products.push({ ...product })
                });

                let userlanguagedb = weblanguagedb.get(`${data.user.id}`) || "EN"
                language = userlanguagedb
                args = {
                    user: {
                        avatar: `${data.user.avatar}`,
                        username: data.user.username,
                        discriminator: data.user.discriminator,
                        id: data.user.id,
                    },
                    orderCards: {
                        Products: products
                    },
                    data: {
                        reviews: reviews,
                        login: true,
                        userCoins: usercoins,
                        language: language,
                        page: {
                            pageName: req.url.replace("/", ''),
                            view: req.url,
                            data: {}
                        },
                    },
                    system: {
                        logs: logsdb.get(`Logs_${data.user.id}`)?.reverse() || []
                    }
                }
            }

            if (Object.keys(blacklistSchema).length > 0) {
                let checkblacklist = await blacklistSchema.findOne({ userid: data.user.id })
                if (checkblacklist) {
                    return res.end(`<script>window.location.href = "/";</script>`);
                }
            }

            res.render(`./website/html/Pages/Dashboard/Order/hosts.ejs`, args);
        } else {
            return res.end(`<script>window.location.href = "/";</script>`);
        }
    }
}
